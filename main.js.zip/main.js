'use strict';

{
   document.querySelector('button').addEventListener('click', () => {
      let fizz = document.querySelectorAll('input')[0];
      let buzz = document.querySelectorAll('input')[1];

      let FizzNumInput = parseInt(fizz.value); //FizzNumInput入力値を整数で取得
      let BuzzNumInput = parseInt(buzz.value); //FizzNumInput入力値を整数で取得

      let ul = document.querySelector('ul'); //ulを選択

      console.log(typeof fizz.value);

      if (
         Number.isInteger(FizzNumInput) != true ||
         Number.isInteger(BuzzNumInput) != true ||
         // Number.isInteger(FizzNumInput)  ||
         // Number.isInteger(BuzzNumInput)  ||
         FizzNumInput === '' ||
         BuzzNumInput === ''
      ) {
         ul.textContent = '整数値を入力してください'; //¥  エラーメッセージ そのままulを書き換えている
         // ul.appendChild(ul); //! 上で直接書き換えているので不要
         return;
      }

      //¥　while文作成========================
      let i = 1;
      let j = 1;

      while (i * FizzNumInput <= 99 || j * BuzzNumInput <= 99) {
         let Li = document.createElement('li'); //Fizz用のliを生成
         if (i * FizzNumInput < j * BuzzNumInput) {
            Li.textContent = `Fizz ${i * FizzNumInput}`;
            ul.appendChild(Li);
            i++;
         } else if (j * BuzzNumInput < i * FizzNumInput) {
            Li.textContent = `Buzz ${j * BuzzNumInput}`;
            ul.appendChild(Li);
            j++;
         } else {
            Li.textContent = `FizzBuzz ${i * FizzNumInput}`;
            ul.appendChild(Li);
            i++;
            j++;
         }
      }

      console.log(typeof FizzNumInput);
      console.log(typeof BuzzNumInput);
   });
}

//¥　isNaN() は、引数が数値でない場合に true を返し、数値の場合は false を返します。

console.log('★★★★★★★★★★★★★★★ #placeholder ★★★★★★★★★★★★★★★★★');
function gcd(a, b) {
   if (b != 0) return gcd(b, a % b);
   //10  4 b===0になるまで gcd(a,b)を繰り返す。← returnで関数が呼び出されるため＝ループ
   else return a;
}

const a = function lcm(a, b) {
   return (a * b) / gcd(a, b); //　2
};

console.log(a(4, 10));

//--------------for文ではインクレメントを２種類に分けて実行できない--------
// let multiplyFizz = () => {
//    for (let i = 1; i * FizzNumInput <= 99; i++) {
//       return FizzNumInput * i;
//    }
// };

// let multiplyBuzz = () => {
//    for (let i = 1; i * BuzzNumInput <= 99; i++) {
//       return BuzzNumInput * i;
//    }
// };

// for (let i = 1; i < 300; i++) {
//    if (multiplyFizz() > multiplyBuzz()) {
//       console.log("AAAAAAA");
//    } else if (multiplyFizz() < multiplyBuzz()) {
//       console.log("AAAAAAA");
//    } else {
//       console.log('CCCCCC');
//    }
// }
//------------------------
